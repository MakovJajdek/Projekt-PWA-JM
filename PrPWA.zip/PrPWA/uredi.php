<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Naslovnica</a></li>
        <li><a href="clanak.php">Clanak</a></li>
        <li><a href="unos.html">Unos</a></li>
        <li><a href="registracija.php">Registracija</a></li>
      </ul>
    </nav>
  </header>

  <section>
    <h2>Uređivanje vijesti</h2>
    <?php
    // Povezivanje s bazom podataka (ponovno)
    $servername = "localhost";
    $username = "PWA";
    $password = "pwaprojekt";
    $dbname = "pwa-projekt";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
    }

    // Provjera je li poslana forma za ažuriranje vijesti
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $id = $_POST["id"];
      $naslov = $_POST["naslov"];
      $sazetak = $_POST["sazetak"];
      $tekst = $_POST["tekst"];

      $updateSql = "UPDATE vijesti SET naslov = '$naslov', sazetak = '$sazetak', tekst = '$tekst' WHERE id = '$id'";

      if ($conn->query($updateSql) === TRUE) {
        echo "Vijest je uspješno ažurirana.";
      } else {
        echo "Pogreška pri ažuriranju vijesti: " . $conn->error;
      }
    }

    // Dohvaćanje pojedinačne vijesti za uređivanje
    if (isset($_GET['id'])) {
      $id = $_GET['id'];
      $selectSql = "SELECT id, naslov, sazetak, tekst FROM vijesti WHERE id = '$id' LIMIT 1";
      $result = $conn->query($selectSql);

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          ?>
          <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <label>Naslov:</label>
            <input type="text" name="naslov" value="<?php echo $row['naslov']; ?>"><br>
            <label>Sažetak:</label>
            <textarea name="sazetak"><?php echo $row['sazetak']; ?></textarea><br>
            <label>Tekst:</label>
            <textarea name="tekst"><?php echo $row['tekst']; ?></textarea><br>
            <input type="submit" value="Spremi">
          </form>
          <?php
        }
      } else {
        echo "Nema dostupne vijesti za uređivanje.";
      }
    } else {
      echo "Nije definiran ID vijesti za uređivanje.";
    }

    $conn->close();
    ?>
  </section>

  <footer>
  <p>Jakov Majdek</p>
  </footer>
</body>
</html>
