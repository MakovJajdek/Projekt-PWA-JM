<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Naslovnica</a></li>
        <li><a href="clanak.php">Clanak</a></li>
        <li><a href="unos.html">Unos</a></li>
        <li><a href="registracija.php">Registracija</a></li>
      </ul>
    </nav>
  </header>

  <section>
    <h2>Administracija vijesti</h2>
    <?php
    // Povezivanje s bazom podataka (ponovno)
    $servername = "localhost";
    $username = "PWA";
    $password = "pwaprojekt";
    $dbname = "pwa-projekt";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
    }

    // Brisanje vijesti
    if (isset($_GET['delete_id'])) {
      $deleteId = $_GET['delete_id'];
      $deleteSql = "DELETE FROM vijesti WHERE id = '$deleteId'";

      if ($conn->query($deleteSql) === TRUE) {
        echo "Vijest je uspješno obrisana.";
      } else {
        echo "Pogreška pri brisanju vijesti: " . $conn->error;
      }
    }

    // Dohvaćanje svih vijesti iz baze
    $sql = "SELECT id, naslov, sazetak, tekst FROM vijesti";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<article>";
        echo "<h3>" . $row["naslov"] . "</h3>";
        echo "<p>" . $row["sazetak"] . "</p>";
        echo "<p>" . $row["tekst"] . "</p>";
        echo "<p><a href='uredi.php?id=" . $row["id"] . "'>Uredi</a> | <a href='administrator.php?delete_id=" . $row["id"] . "' onclick='return confirm(\"Jeste li sigurni da želite obrisati ovu vijest?\")'>Obriši</a></p>";
        echo "</article>";
      }
    } else {
      echo "Nema dostupnih vijesti.";
    }

    $conn->close();
    ?>
  </section>

  <footer>
  <p>Jakov Majdek</p>
  </footer>
</body>
</html>
