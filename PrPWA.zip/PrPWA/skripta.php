<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $naslov = $_POST["naslov"];
  $sazetak = $_POST["sazetak"];
  $tekst = $_POST["tekst"];
  $kategorija = $_POST["kategorija"];
  $obavijest = isset($_POST["obavijest"]) ? $_POST["obavijest"] : "ne";

  // Povezivanje s bazom podataka
  $servername = "localhost";
  $username = "PWA";
  $password = "pwaprojekt";
  $dbname = "pwa-projekt";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
  }

  // Pohrana podataka u bazu
  $sql = "INSERT INTO vijesti (naslov, sazetak, tekst, kategorija, obavijesti) VALUES ('$naslov', '$sazetak', '$tekst', '$kategorija', '$obavijest')";

  if ($conn->query($sql) === TRUE) {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' type='text/css' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "<header>";
    echo "<nav>";
    echo "<ul>";
    echo "<li><a href='index.php'>Naslovnica</a></li>";
    echo "<li><a href='clanak.php'>Clanak</a></li>";
    echo "<li><a href='unos.html'>Unos</a></li>";
    echo "</ul>";
    echo "</nav>";
    echo "</header>";

    echo "<div class='content'>";
    echo "<h1>Unos novih vijesti</h1><br>";
    echo "<h2>Podaci koje ste unijeli:</h2>";
    echo "<p><strong>Naslov:</strong> " . $naslov . "</p>";
    echo "<p><strong>Kratki sazetak:</strong> " . $sazetak . "</p>";
    echo "<p><strong>Tekst:</strong> " . $tekst . "</p>";
    echo "<p><strong>Kategorija:</strong> " . $kategorija . "</p>";
    echo "<p><strong>Prikazati obavijest:</strong> " . ($obavijest == "da" ? "Da" : "Ne") . "</p>";
    echo "</div>";

    echo "<footer>";
    echo "<p>&copy; 2023 Moja Stranica. Sva prava pridrzana.</p>";
    echo "</footer>";
    echo "</body>";
    echo "</html>";
  } else {
    echo "Pogreška pri unosu podataka: " . $conn->error;
  }

  $conn->close();
}
?>