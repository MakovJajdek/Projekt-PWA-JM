<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Naslovnica</a></li>
        <li><a href="clanak.php">Clanak</a></li>
        <li><a href="unos.html">Unos</a></li>
        <li><a href="registracija.php">Registracija</a></li>
      </ul>
    </nav>
  </header>

  <section>
    <h2>Musica</h2>
    <?php
    // Povezivanje s bazom podataka
    $servername = "localhost";
    $username = "PWA";
    $password = "pwaprojekt";
    $dbname = "pwa-projekt";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
    }

    // Dohvaćanje vijesti iz baze
    $sql = "SELECT id,naslov, sazetak FROM vijesti WHERE kategorija = 'Musica'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<article>";
        echo "<h3><a class='link-vijesti' href='clanak.php?id=" . $row["id"] . "'>" . $row["naslov"] . "</a></h3>";
        echo "<p>" . $row["sazetak"] . "</p>";
        echo "</article>";
      }
    } else {
      echo "Nema dostupnih vijesti.";
    }

    $conn->close();
    ?>
  </section>
  
  <section>
    <h2>Sport</h2>
    <?php
    // Povezivanje s bazom podataka (ponovno)
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
    }

    // Dohvaćanje vijesti iz baze
    $sql = "SELECT id,naslov, sazetak FROM vijesti WHERE kategorija = 'Sport'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<article>";
        echo "<h3><a class='link-vijesti' href='clanak.php?id=" . $row["id"] . "'>" . $row["naslov"] . "</a></h3>";
        echo "<p>" . $row["sazetak"] . "</p>";
        echo "</article>";
      }
    } else {
      echo "Nema dostupnih vijesti.";
    }

    $conn->close();
    ?>
  </section>

  <footer>
  <p>Jakov Majdek</p>
  </footer>
</body>
</html>
