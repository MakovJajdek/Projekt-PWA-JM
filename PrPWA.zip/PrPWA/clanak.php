<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Naslovnica</a></li>
        <li><a href="clanak.php">Clanak</a></li>
        <li><a href="unos.html">Unos</a></li>
        <li><a href="registracija.php">Registracija</a></li>
      </ul>
    </nav>
  </header>

  <section class="clanaksec">
    <h2>Musica</h2>
    <?php
// Povezivanje s bazom podataka (ponovno)
$servername = "localhost";
$username = "PWA";
$password = "pwaprojekt";
$dbname = "pwa-projekt";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Pogreška pri povezivanju s bazom podataka: " . $conn->connect_error);
}

// Provjeravanje je li prenesen ID vijesti kao parametar
if (isset($_GET["id"])) {
  $id = $_GET["id"];

  // Dohvaćanje vijesti iz baze na temelju ID-a
  $sql = "SELECT naslov, sazetak, tekst FROM vijesti WHERE id = $id";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      echo "<article>";
      echo "<h2>" . $row["naslov"] . "</h2>";
      echo "<p>" . $row["sazetak"] . "</p>";
      echo "<p>" . $row["tekst"] . "</p>";
      echo "</article>";
    }
  } else {
    echo "Nema dostupnih članaka.";
  }
} else {
  echo "Nije prenesen ID vijesti.";
}

$conn->close();
?>

  </section>

  <footer>
    <p>Jakov Majdek</p>
  </footer>
</body>
</html>
