<?php
// Provjera je li forma poslana
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Uspostavljanje veze s bazom podataka (pretpostavlja se da su podaci o bazi već postavljeni)
  $servername = "localhost";
  $username = "PWA";
  $password = "pwaprojekt";
  $dbname = "pwa-projekt";

  // Stvaranje novog PDO objekta za rad s bazom podataka
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Postavljanje načina rukovanja greškama PDO-a na iznimke
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
  }

  // Priprema i izvršavanje upita za unos korisnika
  $stmt = $conn->prepare("INSERT INTO korisnici (korisnicko_ime, lozinka) VALUES (:korisnicko_ime, :lozinka)");
  $stmt->bindParam(':korisnicko_ime', $_POST['korisnicko_ime']);
  $stmt->bindParam(':lozinka', $_POST['lozinka']);
  $stmt->execute();

  $korisnicko_ime = $_POST['korisnicko_ime'];
  $lozinka = $_POST['lozinka'];

  if ($korisnicko_ime === 'admin' && $lozinka === 'admin') {
    // Ako su korisničko ime i lozinka ispravni, preusmjeri na administrator.php
    header("Location: administrator.php");
    exit;
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Naslovnica</a></li>
        <li><a href="clanak.php">Clanak</a></li>
        <li><a href="unos.html">Unos</a></li>
        <li><a href="registracija.php">Registracija</a></li>
      </ul>
    </nav>
  </header>
  <h1>Registracija korisnika</h1>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
    <label for="korisnicko_ime">Korisničko ime:</label><br>
    <input type="text" id="korisnicko_ime" name="korisnicko_ime" required><br>

    <label for="lozinka">Lozinka:</label><br>
    <input type="password" id="lozinka" name="lozinka" required><br>

    <input type="submit" value="Registriraj se">
  </form>
  <footer>
  <p>Jakov Majdek</p>
  </footer>
</body>
</html>
